import React, { Component } from 'react';
import { Container,Row,Col } from 'reactstrap';
import './Withdraw.scss';
import Icon1 from '../../assets/icon1.png'

export default class Withdraw extends Component{
    constructor(props){
        super(props);
    }
    render(){
        return(
            <Container fluid={true} className="withdraw-card">
                <Row className="withdraw-card__main">
                    <Col lg={3} xs={3} style={{padding:"0px !important"}}>
                        <div className="icon"
                        style={{background:"linear-gradient(262deg,"+
                        this.props.bgStartColor +" 8%," 
                        + this.props.bgEndColor+ " 98%)"}}
                        >
                          <img src={this.props.icon} style={{padding:"8px"}}></img>
                        </div>
                    </Col>
                    <Col lg={9} xs={9}>
                         <h6>Total Earn from daily Profits</h6>
                         <h2 style={{color:""+this.props.color}}>0</h2>
                    </Col>
                </Row>
            </Container>
        )
    }
}