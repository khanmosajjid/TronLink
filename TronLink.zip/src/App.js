import logo from './logo.svg';
import './App.css';
import Home from './components/home'
import Header from './components/Header/Header'
import Payment from './components/Payment/Payment';
import Footer from './components/Footer/Footer';
import Main from './components/Main';
import LandingPage from './LandingPage/landingPage'

function App() {
  return (
    <div className="App">
      <LandingPage></LandingPage>
      {/* <Main></Main> */}
      
      
    </div>
  );
}

export default App;
