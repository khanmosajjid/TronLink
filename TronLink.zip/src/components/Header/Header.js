import React, { Component } from 'react';
import './Header.scss';
import {Container,Row,
           Col,Label,Input} from 'reactstrap';
import logo from '../../assets/logo.png';
import { Icon } from 'semantic-ui-react'

export default class Header extends Component{
    render(){
        return(
            <Container fluid={true} className="header"> 
                <Row className="header-row">
                    <Col lg={6} className="header__logo">
                        <img src={logo} alt="compony-logo"></img>
                    </Col>
                    <Col lg={6} className="header__containt">
                        <Row className="header__containt-report">
                            <Col lg={5} className="header__containt-dailyreport">
                                <Icon name="clock" style={{color:"#0d64b1"}}></Icon>
                                <p >Daily Trading reports</p>
                            </Col>
                            <Col lg={6} className="header__containt-weeklyreport">
                            <Icon name="calendar" style={{color:"red"}}></Icon>
                                <p>Weekly Trading reports</p>
                            </Col>

                        </Row>
                    </Col>
                </Row>
            </Container>
        )
    }
}