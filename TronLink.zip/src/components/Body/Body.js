import React, { Component } from "react";
import { Container, Row, Col, Button } from "reactstrap";
import "./Body.scss";
import { Icon } from "semantic-ui-react";
import Cards from './Cards/Cards';
import Youtube from '../Youtube/Youtube';
import Bitcoin from '../../assets/bitcoin.png';
import bodyicon1 from '../../assets/bodyicon1.png'
import bodyicon2 from '../../assets/bodyicon2.png'
import bodyicon3 from '../../assets/bodyicon3.png'
import videohead from '../../assets/videohead.png'
export default class Body extends Component {
  render() {
    return (
      <Container fluid={true} className="body-main">
        <Row>
          <Col lg={6} className="body-main__content">
            <h1>Multiply</h1>
            <h2>
              Your <span>Tron</span> With US
            </h2>
            <Col lg={12} className="body-main__list">
              <Icon
                name="check circle outline"
                style={{ marginTop: "7px", marginLeft: "5px" }}
              ></Icon>
              <p>Earn 200% on your investement</p>
            </Col>
            <Col lg={12} className="body-main__list">
              <Icon
                name="check circle outline"
                style={{ marginTop: "7px", marginLeft: "5px" }}
              ></Icon>
              <p>Earn 200% on your investement</p>
            </Col>
            <Col lg={12} className="body-main__list">
              <Icon
                name="check circle outline"
                style={{ marginTop: "7px", marginLeft: "5px" }}
              ></Icon>
              <p>Earn 200% on your investement</p>
            </Col>
            <Col lg={12} className="body-main__list">
              <Icon
                name="check circle outline"
                style={{ marginTop: "7px", marginLeft: "5px" }}
              ></Icon>
              <p>Earn 200% on your investement</p>
            </Col>
            <Col lg={12} className="body-main__list">
              <Icon
                name="check circle outline"
                style={{ marginTop: "7px", marginLeft: "5px" }}
              ></Icon>
              <p>Earn 200% on your investement</p>
            </Col>
            <Col lg={12} className="body-main__list">
              <Icon
                name="check circle outline"
                style={{ marginTop: "7px", marginLeft: "5px" }}
              ></Icon>
              <p>Earn 200% on your investement</p>
            </Col>
            <Button className="body-main__button">Participate now</Button>
          </Col>
          <Col lg={6} className="body-main__bitcoin">
            <img src={Bitcoin} alt="bitcoin" style={{width:"80%"}}></img>
          </Col>
        </Row>
       
        <Row className="body-main__footer">
          <Row className="footer-body">
            <Col lg={4} xs={4} className="footer-content">
              <img src={bodyicon1} style={{marginRight:"10px"}}></img>
              <p>Check our Contract</p>
            </Col>
            <Col lg={4} xs={4} className="footer-content">
            <img src={bodyicon2} style={{marginRight:"10px"}}></img>
              <p>Check our Complete Plan</p>
            </Col>
            <Col lg={4} xs={4} className="footer-content" style={{borderRight: "2px solid #39475b"}}>
            <img src={bodyicon3} style={{marginRight:"10px"}}></img>
              <p>Check our Daily Reports</p>
            </Col>
          </Row>
        </Row>
      
      <Row className="body-main__cards">
          <Cards 
          card1Name="Total Deposit"
          card2Name="Total Members"
          card3Name="Total Withdrawn"
          card4Name="Ammount in Trading Pool"
          card1Data="$123"
          card2Data="$123"
          card3Data="$123"
          card4Data="$123"
          ></Cards>

      </Row>
      <Row className="youtube-vid">
        <div>
          <img src={videohead} 
          style={{    marginTop:"-120px",
            width: "100%"}}></img>
        </div>
      <Youtube></Youtube>
      </Row>
      </Container>
    );
  }
}
