import React, { Component } from "react";
import { Button, Col, Container, Row } from "reactstrap";
import "./widget.scss";
import { Icon } from "semantic-ui-react";
import BinaryCommision from './BinaryCommisionCalc/BinaryCommision'

export default class Widget extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: this.props.name,
      trx: this.props.trx,
      logo: this.props.logo,
      level: this.props.level,
      binaryCommision: this.props.binaryCommision,
    };
  }

  render() {
    return (
      <Container fluid={true} className="widget">
        <Row className="widget-box" 
        style={{border:"1px solid " +this.props.color,
        }}>
          <Col lg={3} className="widget-logo" style={{borderRight:"1px solid "+this.props.color}}>
            <div className="widget-logo-style"
            style={{background:"linear-gradient(262deg,"+
            this.props.bgStartColor +" 8%," 
            + this.props.bgEndColor+ " 98%)"}}
            >
              <img src={this.props.image} style={{height:"75px"}}></img>
            </div>
          </Col>
          <Col lg={9} className="widget-details">
            <h3>
              <span style={{color:""+this.props.color}}>{this.props.levelName} </span>
              
            </h3>
            <Row>
              <Col className="details-requirements">
                <Icon name="list alternate outline"></Icon>

                <p>
                  Requirements:
      <span style={{color:""+this.props.color}}>{this.props.levelAmmount}</span>
                  TRX Deposit (you must deposit 100 TRX in order to earn from
                  your referrals)
                </p>
              </Col>
            </Row>

            <Row>
              <Col className="details-requirements">
                <Icon name="list alternate outline"></Icon>

                <p>Commission upto {this.props.levelNumber} Levels</p>
              </Col>
            </Row>

            <Row className="widgets-level-box">
              <Col lg={3}>
                <p>
                  Level 1 = <span style={{color:""+this.props.color}}>4%</span>
                </p>
              </Col>
              <Col lg={3}>
                <p>
                  Level 1 = <span style={{color:""+this.props.color}}>4%</span>
                </p>
              </Col>
              <Col lg={3}>
                <p>
                  Level 1 = <span style={{color:""+this.props.color}}>4%</span>
                </p>
              </Col>
              <Col lg={3}>
                <p>
                  Level 1 = <span style={{color:""+this.props.color}}>4%</span>
                </p>
              </Col>
            </Row>
          </Col>
        </Row>
        

     
       
      </Container>
    );
  }
}
